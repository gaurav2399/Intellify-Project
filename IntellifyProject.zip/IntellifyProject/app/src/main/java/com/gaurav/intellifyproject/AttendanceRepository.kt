package com.gaurav.intellifyproject

import android.util.Log
import androidx.lifecycle.MutableLiveData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AttendanceRepository {
    private lateinit var apiService:AttendanceApi
    operator fun invoke(){
        apiService = RetrofitService.createService(AttendanceApi::class.java)
    }

    fun getApiAttendance(studentId:String):MutableLiveData<ApiResponse>{
        val attendanceData:MutableLiveData<ApiResponse> = MutableLiveData()
        val service = apiService.getAttendance(id = studentId)
        service.enqueue(object : Callback<ApiResponse>{
            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                Log.e("sending request","failed")
                attendanceData.value = null
            }

            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                Log.e("sending request","success")
                if(response.isSuccessful){
                    attendanceData.value = response.body()
                }else{
                    Log.e("getting response","error")
                    Log.e("error",response.message())
                }
            }
        })
        return attendanceData
    }

}