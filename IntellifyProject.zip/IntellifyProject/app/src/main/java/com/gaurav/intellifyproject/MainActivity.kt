package com.gaurav.intellifyproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProviders

class MainActivity : AppCompatActivity() {
    var attendanceArrayList: ArrayList<Attendance> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val attendanceViewModel = ViewModelProviders.of(this).get(AttendanceViewModel::class.java!!)
        attendanceViewModel.invoke()
        attendanceViewModel.getAttendanceRepository()?.observe(this, { attendanceResponse ->
            val attendanceList = attendanceResponse
            attendanceArrayList.addAll(newsArticles)
            newsAdapter.notifyDataSetChanged()
        })

    }
}
