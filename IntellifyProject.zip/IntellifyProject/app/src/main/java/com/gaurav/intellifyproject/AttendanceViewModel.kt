package com.gaurav.intellifyproject

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AttendanceViewModel:ViewModel() {
    private var mutableLiveData:MutableLiveData<ApiResponse>? = null
    private lateinit var attendanceRepository:AttendanceRepository
    operator fun invoke(){
        if(mutableLiveData!=null)
            return
        attendanceRepository = AttendanceRepository()
        mutableLiveData = attendanceRepository.getApiAttendance("1")
    }

    fun getAttendanceRepository():MutableLiveData<ApiResponse>?{
        return mutableLiveData
    }
}