package com.gaurav.intellifyproject


data class ApiResponse(
    val message:String? = null,
    val attendance: List<Attendance>? = null
)