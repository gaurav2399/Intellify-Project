package com.gaurav.intellifyproject

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class AttendanceAdapter: RecyclerView.Adapter<AttendanceAdapter.AttendanceViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AttendanceViewHolder {

    }

    override fun getItemCount(): Int {
    }

    override fun onBindViewHolder(holder: AttendanceViewHolder, position: Int) {
    }

    class AttendanceViewHolder:RecyclerView.ViewHolder() {

    }

}