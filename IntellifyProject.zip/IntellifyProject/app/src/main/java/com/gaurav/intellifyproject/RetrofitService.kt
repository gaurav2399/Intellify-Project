package com.gaurav.intellifyproject

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory



class RetrofitService {
    companion object{
        private val retrofit = Retrofit.Builder()
            .baseUrl("services.intellify.in")
            .addConverterFactory(GsonConverterFactory.create())
            .build()


        fun <T> createService(serviceClass: Class<T>): T {
            return retrofit.create(serviceClass)
        }
    }
}