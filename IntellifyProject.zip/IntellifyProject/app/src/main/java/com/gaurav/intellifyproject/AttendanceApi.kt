package com.gaurav.intellifyproject

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface AttendanceApi {
    @GET("attendance")
    fun getAttendance(
        @Query("for") through:String = "AllClassAttendance",
        @Query("student_id") id:String? = null
    ):Call<ApiResponse>

}